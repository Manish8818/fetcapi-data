const express= require("express");
const app= express();
const port= process.env.port||5000;
// const path= require("path")
// console.log(__dirname)
// const staticpath= path.join(__dirname,"../index.html");
// console.log(staticpath)

// app.use(express.static(staticpath))


// app.get("/",(req,res)=>{
//     res.send()
// })
app.set('view engine', "hbs");
app.get("/registration",(req,res)=>{
    res.render("index")
});

app.post("/login",(req,res)=>{
    res.send("login is sussesfull")
})


//route define//
app.get("/",(req,res)=>{
    res.render("index.hbs")
})

app.listen(port,(req,res)=>{
    console.log("server is listen on the port number 5000")
})